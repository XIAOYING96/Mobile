package com.example.practestfyp

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView

class Exec3 : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_exec3)
    }

    fun chk(view: View) {
        val sellPriceText = findViewById<EditText>(R.id.sp).text.toString()
        val downPaymentText = findViewById<EditText>(R.id.dp).text.toString()

        val sellPrice = sellPriceText.toDoubleOrNull() ?: 0.0
        val downPayment = downPaymentText.toDoubleOrNull() ?: 0.0

        val tvResult=findViewById<TextView>(R.id.tvResult)

        var legalFee=0.0
        var stampDuty=0.0
        var total=0.0

        var loanAmt=
            if (downPayment>=sellPrice * 0.1){
                sellPrice-downPayment
            }else{
                0.0
            }

        if(loanAmt<=500000){
            legalFee=loanAmt*0.01
        }else if (loanAmt<1000000){
            legalFee=(500000*0.01)+((loanAmt-50000) * 0.008)
        }else{
            legalFee=(500000*0.01)+(50000 * 0.008)+((loanAmt-500000)*0.005)
        }
        stampDuty=legalFee*0.005

        total=loanAmt+legalFee+stampDuty

        tvResult.text="Total is RM "+total.toString()
    }

    fun contactUs(view: View) {
        val intentContact:Intent=Intent(Intent.ACTION_VIEW)
        intentContact.data= Uri.parse("tel:01132323232")
        startActivity(intentContact)
    }
}