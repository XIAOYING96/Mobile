package com.example.practestfyp

import android.app.DatePickerDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.fragment.app.DialogFragment
import java.time.LocalDate
import java.time.Month
import java.time.Year

class Exec4 : AppCompatActivity(), DatePickerFragment.OnDateSelectedListener {

    private lateinit var selectedDateTV:TextView
    private lateinit var currentDate:LocalDate
    var age=0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_exec4)

        selectedDateTV=findViewById(R.id.txtDOB)
        currentDate=LocalDate.now()
    }

    private fun calculateDOB(){
        val txtDOB=selectedDateTV.text.toString()


        age=
    }

    fun check(view: View) {}
    fun dateOfBirth(view: View) {
        val newFragment=DatePickerFragment()
        (newFragment as DatePickerFragment).setOnDateSelectedListener(this)
        newFragment.show(supportFragmentManager, "datePicker")

    }

    override fun onDateSelected(year: Int, month: Int, day: Int) {
       val selectedDate=String.format("%02d-%02d-%04d", day, month,year)
        selectedDateTV.text=selectedDate
    }

}