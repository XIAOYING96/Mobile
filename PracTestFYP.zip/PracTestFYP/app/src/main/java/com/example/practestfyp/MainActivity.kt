package com.example.practestfyp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.CheckBox
import android.widget.RadioButton
import android.widget.Spinner
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

    }

    fun chk(view: View) {

        val age = findViewById<Spinner>(R.id.age)
        val male = findViewById<RadioButton>(R.id.male)
        val smoker = findViewById<CheckBox>(R.id.sm)
        val tvResult=findViewById<TextView>(R.id.tvResult)

        var premium = 0
        var extraMale = 0
        var extraSM = 0

        if (age.selectedItemPosition.toString() == "0") {
            premium = 60
        } else if (age.selectedItemPosition.toString() == "1") {
            premium = 70
            if (male.isChecked) {
                extraMale = 50
                if (smoker.isChecked) {
                    extraSM = 100
                }
            }
        } else if (age.selectedItemPosition.toString() == "2") {
            premium = 70
            if (male.isChecked) {
                extraMale = 50
                if (smoker.isChecked) {
                    extraSM = 100
                }
            }
        } else if (age.selectedItemPosition.toString() == "3") {
            premium = 90
            if (male.isChecked) {
                extraMale = 100
                if (smoker.isChecked) {
                    extraSM = 150
                }
            }
        } else if (age.selectedItemPosition.toString() == "4") {
            premium = 120
            if (male.isChecked) {
                extraMale = 150
                if (smoker.isChecked) {
                    extraSM = 200
                }
            }
        } else if (age.selectedItemPosition.toString() == "5") {
            premium = 150
            if (male.isChecked) {
                extraMale = 200
                if (smoker.isChecked) {
                    extraSM = 250
                }
            }
        } else if (age.selectedItemPosition.toString() == "6") {
            premium = 150
            if (male.isChecked) {
                extraMale = 200
                if (smoker.isChecked) {
                    extraSM = 300
                }
            }
        }

        tvResult.text="Premium is "+premium.toString()+" , Extra for male is " + extraMale.toString()+" , " +
                "Extra for smoker is "+extraSM.toString()
    }
}