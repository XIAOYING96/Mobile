package com.example.practocal_2_1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Exercise : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_exercise)
    }
}