package com.example.practocal_2_1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Switch
import androidx.appcompat.app.AppCompatDelegate

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        // Declare the switch from the layout file

        val btn = findViewById<Switch>(R.id. darkMode_switch)

// set the switch to listen on checked change

        btn.setOnCheckedChangeListener{buttonView, isChecked->

// if the button is checked, i.e., towards the right or enabled

            if (isChecked) {

                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)

            } else {

                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

            }

        }
        val button = findViewById<Button>(R.id.exercise_button)
        button.setOnClickListener {
            val intent = Intent(this, Exercise::class.java)
            startActivity(intent)
        }
    }
}